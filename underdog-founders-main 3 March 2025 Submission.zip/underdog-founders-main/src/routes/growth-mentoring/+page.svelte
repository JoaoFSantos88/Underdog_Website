<script>
    import HeroSection from "$lib/components/HeroSection/HeroSection.svelte";
  import CallToAction from "$lib/components/CallToAction/CallToAction.svelte";
  import ClientCaseStudy1 from "$lib/components/CaseStudy/ClientCaseStudy1.svelte";
  import ClientCaseStudy2 from "$lib/components/CaseStudy/ClientCaseStudy2.svelte";
  import ClientCaseStudy3 from "$lib/components/CaseStudy/ClientCaseStudy3.svelte";
  import HowIHelp from "$lib/components/HowIHelp/HowIHelp.svelte";
  import ProudPartners from "$lib/components/ProudPartners/ProudPartners.svelte";
  import Testimonials from "$lib/components/Testimonials/Testimonials.svelte";


</script>


<main class="bg-white pb-32">
    <HeroSection/>
    <HowIHelp/>
    <ClientCaseStudy1/>
    <ClientCaseStudy2/>
    <ClientCaseStudy3/>
    <Testimonials/>
    <CallToAction/>
    <ProudPartners/>
</main>



