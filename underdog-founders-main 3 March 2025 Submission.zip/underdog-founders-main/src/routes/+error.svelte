<section class="prose mx-auto">
    <div class="py-8 px-4 max-w-screen-xl lg:py-16 lg:px-6">
        <div class="mx-auto max-w-screen-sm text-center">
            <h1 class="mb-4 text-7xl tracking-tight font-extrabold lg:text-9xl">404</h1>
            <p class="mb-4 text-3xl tracking-tight font-bold  md:text-4xl dark:text-white">Oops. Something's missing.</p>
            <p class="mb-4 text-lg font-light ">Sorry, we can't find that page.</p>
            <a href="/" class="">Back to Homepage</a>
        </div>
    </div>
</section>