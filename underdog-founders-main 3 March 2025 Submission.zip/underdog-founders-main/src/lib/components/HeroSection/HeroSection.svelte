<section
  class="container mx-auto px-6 pt-52 pb-16 md:py-32 lg:pt-72 lg:pb-32 relative overflow-hidden bg-white"
>
  <div
    class="flex flex-col lg:flex-row items-center lg:items-start justify-center lg:justify-start"
  >
    <div class="relative z-10 text-center lg:text-left lg:ml-32 max-w-2xl">
      <h1 class="h1 balanced text-primary-500 text-2xl md:text-4xl lg:text-7xl">
        Growth Mentoring
      </h1>
      <p class="text-black font-sans text-lg md:text-xl mt-4">
        +10 years in startups and VC funds for the price of an intern.
      </p>
      <a href="mailto:joao@underdog-founders.com">
        <button
          class="mt-6 px-6 py-3 primary-button font-sans rounded-lg shadow-lg transition"
        >
          Book a Call
        </button>
      </a>
    </div>
  </div>
</section>
