<div class=" mt-24 bg-white items-center flex flex-col justify-center p-4">
  <h2 class="text-3xl font-bold mb-1 font-sans text-black">Growth Mentoring</h2>
  <p class="text-black font-sans text-lg text-center">
    +10 years in startups and VC funds for the price of an intern.
  </p>
  <a href="mailto:joao@underdog-founders.com">
    <button class="secondary-button font-sans font-semibold">Book a Call</button
    >
  </a>
</div>
