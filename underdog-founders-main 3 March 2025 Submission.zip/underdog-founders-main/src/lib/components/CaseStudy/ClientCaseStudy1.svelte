<script>
  import FounderImage from "../../assets/images/Founder.png";
</script>

<div class="mt-32 bg-white">
  <div class="max-w-4xl p-6 mx-auto">
    <h2 class="text-2xl lg:text-4xl font-bold font-sans text-black">
      Get the yes from investors
    </h2>
    <h3 class="text-2xl lg:text-4xl text-black font-sans">Client Case Study</h3>

    <div class="grid md:grid-cols-[7fr_3fr] gap-6 items-center">
      <!-- Left Content (70%) -->
      <div class="space-y-4 text-black">
        <p class="font-sans text-lg">
          Luggit is a tech platform connecting tourists that need a place to
          leave their luggage with professional drivers, who pick it up and drop
          it off at any location.
        </p>
        <p class="font-sans text-lg">
          They were growing in their home market, but their pitch didn't show
          investors why they had a shot at being a global leader.
        </p>
        <p class="font-semibold font-sans text-lg">
          Until I discovered their 70% partner conversion rate… and the rest was
          history.
        </p>
        <p class="font-sans text-lg">
          Their growth was coming from contacting property managers that
          operated +10 Airbnb units. Luggit offered their service for free to
          the property managers, who had clients asking them about where to
          leave their luggage all the time.
        </p>
        <p class="font-sans text-lg">
          The guests paid a fee when they used Luggit, it was a win-win at zero
          cost for the property managers. We dug into it, found out they were
          converting 70% of all contacted managers, and used this data to raise
          investor confidence and close the round.
        </p>
      </div>

      <!-- Right Image (30%) -->
      <div class="relative flex justify-center">
        <img
          src={FounderImage}
          alt="Client Case Study"
          class="w-60 h-60 object-cover rounded-full"
        />
      </div>
    </div>
  </div>
</div>
