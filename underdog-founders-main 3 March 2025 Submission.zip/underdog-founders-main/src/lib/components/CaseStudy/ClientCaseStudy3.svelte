<script>
  import socialMediaStats from '$lib/assets/images/socialmediastats.png'; // Update the path if needed
</script>

<div class=" mt-36 bg-white">
    <div class="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-[35%_65%] gap-8 items-center p-6">
  <!-- Right Content (Now on the Left) -->
  <div class="text-black flex flex-col items-start text-left">
    <!-- Headings aligned to the top-left -->
    <h2 class="text-2xl lg:text-4xl font-bold font-sans whitespace-nowrap">Blow up on social media
</h2>
    <h1 class="mb-4 font-sans text-2xl lg:text-4xl">Client Case Study</h1>

    <!-- Normal text content -->
    <div class="text-left w-full">
      <p class="mb-3 font-sans text-xl">
VAST's post impressions grew by 2-3x
as soon as they started following our
content playbook.
    </p>
      <p class="mb-3 font-sans text-xl">
       They went from thinking that social media would not work in their industry, to getting prospects asking them for a meeting after seeing their content.
      </p>
      
    </div>
  </div>

  <!-- Left Image (Now on the Right) -->
  <div class="flex justify-center">
    <img src={socialMediaStats} alt="Handprint Case Study" class="w-[90%] h-full rounded-lg shadow-md" />
  </div>
</div>

</div>
