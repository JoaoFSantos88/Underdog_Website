underdog founders website.

npm install
npm run dev

this should get the app up and running
